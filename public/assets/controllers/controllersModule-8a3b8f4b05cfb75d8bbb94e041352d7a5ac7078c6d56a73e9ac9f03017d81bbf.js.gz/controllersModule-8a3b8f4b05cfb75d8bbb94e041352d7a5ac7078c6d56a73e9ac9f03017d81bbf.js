'use strict';

angular.module('controllers', []);
